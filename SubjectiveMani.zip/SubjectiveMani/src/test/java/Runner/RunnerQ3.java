package Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"C:\\Users\\manigandang\\Desktop\\Sample\\Training\\FeatureFiles\\Q3s1.feature",
				"C:\\Users\\manigandang\\Desktop\\Sample\\Training\\FeatureFiles\\Q3s2.feature",
				"C:\\Users\\manigandang\\Desktop\\Sample\\Training\\FeatureFiles\\Q3s3.feature"},
		glue = "Q3"
		)
public class RunnerQ3 {

}
